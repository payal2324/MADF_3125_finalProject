package com.example.macstudent.c0718456_madf3125_finalexamcode;

import android.app.Activity;


import android.location.Location;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import com.example.macstudent.c0718456_madf3125_finalexamcode.modal.Locations;

import java.lang.String;
import java.util.ArrayList;
import java.util.List;

public class LocationsListActivity extends Activity {

    ArrayList <Locations> LocList = new ArrayList<Locations>();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_locations_list);

        ListView LocationList = (ListView)findViewById(R.id.locationsListView);
        initLoc();
        ArrayAdapter<Locations> arrayAdapter =
                new ArrayAdapter<Locations>(this, android.R.layout.simple_list_item_1, LocList);
        LocationList.setAdapter(arrayAdapter);
        LocationList.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> arg0, View v,int i, long arg3) {
                Locations selectedLocation = LocList.get(i);
                Toast.makeText(getApplicationContext(), "Location Selected : "+selectedLocation,   Toast.LENGTH_LONG).show();
            }
        });

}
    public void initLoc() {

        Locations loc1 = new Locations(1,"Toronto");
        LocList.add(loc1);
        Locations loc2 = new Locations(2, "CN Tower");
        LocList.add(loc2);
        Locations loc3 = new Locations(3, "Niagra");
        LocList.add(loc3);
        Locations loc4 = new Locations(4,"Alberta");
        LocList.add(loc4);
        Locations loc5 = new Locations(5, "Chicago");
        LocList.add(loc5);
        Locations loc6 = new Locations(6, "Vancouver");
        LocList.add(loc6);

    }
}