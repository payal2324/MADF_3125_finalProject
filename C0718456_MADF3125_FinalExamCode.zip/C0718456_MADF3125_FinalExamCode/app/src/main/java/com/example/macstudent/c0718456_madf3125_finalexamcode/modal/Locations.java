package com.example.macstudent.c0718456_madf3125_finalexamcode.modal;


import java.lang.String;
/**
 * Created by macstudent on 2017-12-13.
 */

public class Locations

{
    int locationId;
    public String locationName;
    long latitude;
    long longitude;


    public Locations() {
    }

    public Locations(int locationId) {
        this.locationId = locationId;
    }

    public Locations(int locationId, String locationName, long latitude, long longitude) {
        this.locationId = locationId;
        this.locationName = locationName;
        this.latitude = latitude;
        this.longitude = longitude;
    }

    public Locations(int locationId, String locationName) {
        this.locationId = locationId;
        this.locationName = locationName;
    }

    public int getLocationId() {
        return locationId;
    }

    public String getLocationName() {
        return locationName;
    }

    public long getLatitude() {
        return latitude;
    }

    public void setLatitude(long latitude) {
        this.latitude = latitude;
    }

    public long getLongitude() {
        return longitude;
    }

    public void setLongitude(long longitude) {
        this.longitude = longitude;
    }

    public void setLocationId(int locationId) {
        this.locationId = locationId;
    }

    public void setLocationName(String locationName) {
        this.locationName = locationName;
    }

    @Override
    public String toString() {
        return "Locations{" +
                "locationId=" + locationId +
                ", locationName='" + locationName + '\'' +
                '}';
    }
}
